import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const FD_ACCOUNTS_API = `${import.meta.env.VITE_API_BASE_URL}`;

export const fdAccounts = createApi({
  baseQuery: fetchBaseQuery({
    baseUrl: FD_ACCOUNTS_API,

    prepareHeaders: (headers, { getState }) => {
      const token = getState()?.auth?.token;
      if (token) headers.set("Authorization", `Bearer ${token}`);
      return headers;
    },
  }),
  tagTypes: ["GET_LATEST_FD_DATA_LIST","GET_FD_BASIC_ACCOUNT_DETAILS"],
  endpoints: (builder) => ({
    getAllFdAccountsList: builder.query({
      query: () => ({
        url: `/fd-account/all`,
        method: "GET",
      }),
      providesTags: ["GET_LATEST_FD_DATA_LIST"],
    }),
        getBasicFdAccountDetails: builder.query({
      query: ({ id }) => ({
        url: `/fd-account/basic-details/${id}`,
        method: "GET",
      }),
      providesTags: ["GET_FD_BASIC_ACCOUNT_DETAILS"],
    }),
  }),
});



export const {useGetAllFdAccountsListQuery,useGetBasicFdAccountDetailsQuery}=fdAccounts