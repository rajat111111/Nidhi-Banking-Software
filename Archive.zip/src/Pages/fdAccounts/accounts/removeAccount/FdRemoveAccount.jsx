import RemoveAccount from '../../../savingAccounts/accounts/removeAccount/RemoveAccount'

const FdRemoveAccount = () => {
  return (
    <>
    <RemoveAccount/>
    </>
  )
}

export default FdRemoveAccount