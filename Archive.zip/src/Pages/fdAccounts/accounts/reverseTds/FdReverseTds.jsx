import React, { useMemo } from "react";
import PagesMainContainerStyle from "../../../../components/PagesMainContainerStyle";
import PageHeader from "../../../../components/PageHeader";
import DynamicForm from "../../../../components/DynamicForm";
import * as Yup from "yup";


const FdReverseTds = () => {
  const creditInterestFormList = useMemo(() => {
    const formList = [
      {
        label: "Transaction Date",
        type: "date",
        name: "transactionDate",
      },
      {
        label: "Transaction Type",
        type:"select",
       options: [
        { value: "deduct", label: "Deduct" },
        { value: "credit", label: "Credit" },
      ],
        placeholder: "Enter Transaction Type",
        name: "transactionType",
      },
      {
        label: "Interest Amount",
        type: "number",
        placeholder: "Enter Interest Amount",
        name: "interestAmount",
      },
      {
        label: "Remark",
        placeholder: "Enter Remark",
        name: "remark",
      },
    ];
    return formList;
  }, []);

  const validationSchema = Yup.object({
    transactionDate: Yup.string().required("Transaction Date  is required"),
    transactionType: Yup.string().required("Transaction Type  is required"),
    interestAmount: Yup.number()
      .required("Interest Amount is required")
      .positive("Interest Amount must be positive")
      .typeError("Interest Amount must be a number"),
  });

  const initialValues={
transactionDate:"",
transactionType:"",
interestAmount:"",
remark:""
  }

  return (
    <PagesMainContainerStyle>
      <PageHeader title="Deduct/Reverse TDS" paddingBottom="0px" />
      <DynamicForm
        actionButtonText="Save"
        validationSchema={validationSchema}
        texting="Saving"
        initialValues={initialValues}
        formList={creditInterestFormList}
      />
    </PagesMainContainerStyle>
  );
};

export default FdReverseTds;
