import React from 'react'

const FdUpgradeAccountType = () => {
  return (
    <div>FdUpgradeAccountType</div>
  )
}

export default FdUpgradeAccountType