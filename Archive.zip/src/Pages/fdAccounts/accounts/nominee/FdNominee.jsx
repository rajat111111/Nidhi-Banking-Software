import React from 'react'
import Nominee from '../../../savingAccounts/accounts/nominee/Nominee'

const FdNominee = () => {
  return (
    <>
  <Nominee/>
    </>
  )
}

export default FdNominee