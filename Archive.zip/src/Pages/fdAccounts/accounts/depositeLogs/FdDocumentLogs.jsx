import React from 'react'
import PagesMainContainerStyle from '../../../../components/PagesMainContainerStyle'
import PageHeader from '../../../../components/PageHeader'
import DynamicDataTable from '../../../../components/DynamicTable'

const FdDocumentLogs = () => {

  const columns = [
    { id: "id", label: "#", minWidth: 50 },
    { id: "transactionDate", label: "Transaction Date", minWidth: 120 },
    { id: "transactionId", label: "Transaction ID", minWidth: 120 },
    { id: "transactionMode", label: "Transaction Mode", minWidth: 120 },
    { id: "remark", label: "Remark", minWidth: 180,alignItems:"center" },
    { id: "depositAmount", label: "Deposit Amount", minWidth: 100 },
 

    { id: "balance", label: "Balance", minWidth: 100 },
    { id: "action", label: "Status", minWidth: 100 },
  ];

  const rows=[]

  return (
    
    <PagesMainContainerStyle>
      <PageHeader onFilter title="FD Bond" paddingBottom="0px" />
        <DynamicDataTable rows={rows} columns={columns} />
    </PagesMainContainerStyle>
    
  )
}

export default FdDocumentLogs