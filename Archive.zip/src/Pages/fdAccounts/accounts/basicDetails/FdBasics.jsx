import InformationPage from "../../../../components/InformationPage";
import { useParams } from "react-router-dom";
import PageLoader from "../../../../components/PageLoader";
import { capitalizeFirstLetter } from "../../../../helper/helper";
import { useGetBasicFdAccountDetailsQuery } from "../../../../features/api/fdAccounts";

const FdBasics = () => {
  const { id } = useParams();
  const { data, isLoading } = useGetBasicFdAccountDetailsQuery({ id });

  const basicDetails = data?.data || {};
  console.log("basicDetails", basicDetails);

  // Destructure safely from API
  const {
    member,
    memberNo,
    agentName,
    principalAmount,
    openDate,
    annualInterestRate,
    maturityDate,
    status,
    seniorCitizen,
    approvedBy,
    approvedDate,
    fdNumber,
    branchName,
    plan,
    paymentMode,
    maturityAmount,
    balance,
    interestPayout,
    tdsDeduction,
    autoRenewal,
    address,
  } = basicDetails;

  // 🔹 Left section
  const key1 = [
    "Member",
    "Member No.",
    "Agent Name",
    "Principal Amount",
    "Open Date",
    "Annual Interest Rate",
    "Maturity Date",
    "Status",
    "Senior Citizen",
    "Approved By",
    "Approved Date",
  ];

  const pair1 = [
    member || "N/A",
    memberNo || "N/A",
    agentName || "N/A",
    `₹ ${principalAmount}` || "N/A",
    openDate || "N/A",
    annualInterestRate || "N/A",
    maturityDate || "N/A",
    status === "closed" ? (
      <strong style={{ color: "#de1313" }}>Closed</strong>
    ) : (
      <strong style={{ color: "#1F9C00" }}>Active</strong>
    ),
    seniorCitizen || "N/A",
    approvedBy || "N/A",
    approvedDate ? new Date(approvedDate).toLocaleDateString() : "N/A",
  ];

  // 🔹 Right section
  const key2 = [
    "FD Number",
    "Branch Name",
    "Plan",
    "Payment Mode",
    "Maturity Amount",
    "Balance",
    "Interest Payout",
    "TDS Deduction",
    "Auto Renewal",
    "Address",
  ];

  const pair2 = [
    fdNumber || "N/A",
    branchName || "N/A",
    capitalizeFirstLetter(plan) || "N/A",
    capitalizeFirstLetter(paymentMode) || "N/A",
    `₹ ${maturityAmount}` || "N/A",
    `₹ ${balance}` || "N/A",
    interestPayout || "N/A",
    tdsDeduction || "N/A",
    autoRenewal || "N/A",
    address || "N/A",
  ];

  return (
    <>
      {isLoading ? (
        <PageLoader />
      ) : (
        <InformationPage key1={key1} pair1={pair1} key2={key2} pair2={pair2} />
      )}
    </>
  );
};

export default FdBasics;
