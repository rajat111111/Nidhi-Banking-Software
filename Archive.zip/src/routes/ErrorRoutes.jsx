const ErrorRoutes = {
    path: "*",
    element: <div>404 Not Found</div>,  // Replace with an ErrorPage if you have one
};

export default ErrorRoutes;
